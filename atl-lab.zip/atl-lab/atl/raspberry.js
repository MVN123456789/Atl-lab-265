import React, { Component } from 'react';
import {
  View,
  Text,
  StyleSheet,
  SafeAreaView,
  TouchableOpacity,
  Platform,
  StatusBar,
  ImageBackground,
  Image,
} from 'react-native';
import { Paragraph } from 'react-native-paper';
import { Link } from 'react-router-dom';

export default class Delhi extends Component {
  render() {
    return (
      <View style={styles.container}>
        <SafeAreaView style={styles.droidSafeArea} />
        <ImageBackground
        
          style={styles.backgroundImage}>
          <View style={styles.titleBar}>
            <Text style={styles.titleText}> Raspberry</Text>
          </View>
          <Image
            source={require('../assets/arduino.jpg')}
            style={styles.image}></Image>

          <Paragraph>
           
            Here is information about  arduino:
            <br />
            <br />
            1. It is an open-source project.

            <br />

            2. App based on flexible, easy-to-use hardware and software.

            <br />
            3. It is intended for artists, designers, hobbyists, and anyone interested in creating interactive objects or environments.

            <br />
            4. It is intended to introduce non-technical people to programming, in addition to hobbyists with more experience.

            <br />
            5. The hardware consists of an open-source hardware board designed around an 8-bit Atmel AVR microcontroller, or a 32-bit Atmel ARM.

            6. The board has an integrated circuit microcontroller and a variety of analog and digital input/output (I/O) expansion ports.

            <br />

            7.The software used to drive the board is written in the programming language C/C++ and is available for download from the Arduino website, where it can be modified and redistributed.
            <br />
            8. The software for the board is written primarily in C/C++, with some programs written in Arduino Robot, Processing, and Wiring.
            <br />
            9.Arduino has the ability to be programmed in different languages.
            <br />
            10. Arduino can be programmed using Microchip's PIC microcontrollers.

          </Paragraph>

          <td>
            <a href="https://en.wikipedia.org/wiki/Arduino">
              Click Here to get more Information!
            </a>
          </td>
        </ImageBackground>
      </View>
    );
  }
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  droidSafeArea: {
    marginTop: Platform.OS === 'android' ? StatusBar.currentHeight : 0,
  },
  backgroundImage: {
    flex: 1,
    resizeMode: 'cover',
  },
  titleBar: {
    flex: 0.15,
    justifyContent: 'center',
    alignItems: 'center',
  },
  titleText: {
    fontSize: 40,
    fontWeight: 'bold',
    color: 'black',
    alignItems: 'center',
    marginTop: 10,
  },
  image: {
    width: 200,
    height: 300,
    alignItems: 'center',
    marginLeft: 70,
    marginTop: 20,
  },
});
