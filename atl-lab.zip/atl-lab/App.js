import 'react-native-gesture-handler';
import * as React from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { createStackNavigator } from '@react-navigation/stack';

import HomeScreen from './screens/Home';
import componets from './screens/componets';
import projects from './screens/projects';
import arduino from './atl/ arduino';
import rspberry from './atl/ Raspberry';

const Stack = createStackNavigator();

function App() {
  return (
    <NavigationContainer>
      <Stack.Navigator
        initialRouteName="Home"
        screenOptions={{
          headerShown: false,
        }}>
        <Stack.Screen name="Home" component={HomeScreen} />
        <Stack.Screen name="componets" component={componets} />
        <Stack.Screen name="projects" component={projects} />
        <Stack.Screen name="arduino" component={arduino} />
          <Stack.Screen name="Raspberry" component={raspberry} />
      
      </Stack.Navigator>
    </NavigationContainer>
  );
}

export default App;
